from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
import bot_command as bc


bot = Bot(token=('5618068603:AAGrdmt_esiOm_HoGb3zzyoOrSx9NrMFCOI'))
dp = Dispatcher(bot)

@dp.message_handler(commands=['help'])
async def command_help(message : types.Message):
    await bc.help(message)

@dp.message_handler(commands=['start'])
async def command_start(message : types.Message):
    await bc.start(message)

@dp.message_handler(commands=['kak_dela'])
async def command_kak(message : types.Message):
    await bc.kak_dela(message)

@dp.message_handler(commands=['hello'])
async def command_hello(message : types.Message):
    await bc.hello(message)

@dp.message_handler(commands=['sum'])
async def command_sum(message : types.Message):
    await bc.sum(message)

@dp.message_handler(commands=['sub'])
async def command_sub(message : types.Message):
    await bc.sub(message)

@dp.message_handler(commands=['multi'])
async def command_multi(message : types.Message):
    await bc.multi(message)

@dp.message_handler(commands=['divi'])
async def command_divi(message : types.Message):
    await bc.divi(message)

@dp.message_handler(commands=['Slogenie'])
async def command_Sl(message : types.Message):
    await message.answer('Введите числа, которые хотите посчитать согласно примеру. Пример: "/sum число число" , количество чисел не ограничено')

@dp.message_handler(commands=['Vichitanie'])
async def command_Vi(message : types.Message):
    await message.answer('Введите числа, которые хотите посчитать согласно примеру. Пример: "/sub число число", количество чисел не ограничено')

@dp.message_handler(commands=['Umnogenie'])
async def command_Um(message : types.Message):
    await message.answer('Введите числа, которые хотите посчитать согласно примеру. Пример: "/multi число число", количество чисел не ограничено')

@dp.message_handler(commands=['Delenie'])
async def command_De(message : types.Message):
    await message.answer('Введите числа, которые хотите посчитать согласно примеру. Пример: "/divi число число", количество чисел не ограничено')

@dp.message_handler()
async def echo_send(message : types.Message):
    if message.text == 'hi':
        await message.answer('nice to meet you')

executor.start_polling(dp)