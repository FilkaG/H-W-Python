from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

async def start(message):
    reply_keyboard = [['/Slogenie','/Vichitanie', '/Umnogenie'],['/Delenie', 'Cancel','/hello','/help']]
    markup_key = ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True)
    await message.answer('Добро пожаловать в калькулятор!', reply_markup=markup_key)

async def help(message):
    await message.answer(f'/start\n/hello\n/kak_dela\n/sum\n/sub\n/multi\n/divi\n/help\n')
#
async def kak_dela(message):
    #await log(update, context)
    await message.answer(f'How are you, {message.from_user.first_name}?')
#
async def hello(message):
    #await log(update, context)
    await message.answer(f'Hello {message.from_user.first_name}')

#
async def sum(message):
#    await log(update, context)
    msg = message.text
    line = msg.split()
    answer = 0.0
    line2 = ''
    if msg == '/sum':
        await message.answer(f"NO Numbers!")
    else:
        for i in range(1, len(line)):
            if 'j' in line[i]:
                answer = answer + complex(line[i])
            else:
                answer = answer + float(line[i])
            line2 = line2 + (f"{line[i]} + ")
        line2 = line2[:-2]
        if len(line) == 2: await message.answer(f"{line2}+ 0 = {answer}")
        else: await message.answer(f"{line2}= {answer}")
#
async def sub(message):
#    await log(update, context)
    msg = message.text
    line = msg.split()
    if msg == '/sub':
        await message.answer(f"NO Numbers!")
    else:
        if 'j' in line[1]: answer = complex(line[1])
        else: answer = float(line[1])
        line2 = f"{line[1]}"
        if len(line) == 2:
            await message.answer(f"{line2}- 0 = {answer}")
        else:
            for i in range(2, len(line)):
                if 'j' in line[i]:
                    answer = answer - complex(line[i])
                else:
                    answer = answer - float(line[i])
                line2 = line2 + (f" - {line[i]}")
            await message.answer(f"{line2} = {answer}")
#
async def multi(message):
#    await log(update, context)
    msg = message.text
    line = msg.split()
    if msg == '/multi':
        await message.answer(f"NO Numbers!")
    else:
        if 'j' in line[1]: answer = complex(line[1])
        else: answer = float(line[1])
        line2 = f"{line[1]}"
        if len(line) == 2:
            await message.answer(f"{line2}* 1 = {answer}")
        else:
            for i in range(2, len(line)):
                if 'j' in line[i]:
                    answer = answer * complex(line[i])
                else:
                    answer = answer * float(line[i])
                line2 = line2 + (f" * {line[i]}")
            await message.answer(f"{line2} = {answer}")
#
async def divi(message):
#    await log(update, context)
    msg = message.text
    line = msg.split()
    count = False
    if msg == '/divi':
        await message.answer(f"NO Numbers!")
    else:
        if 'j' in line[1]: answer = complex(line[1])
        else: answer = float(line[1])
        line2 = f"{line[1]}"
        if len(line) == 2:
            await message.answer(f"{line2}/ 1  = {answer}")
        else:
            for i in range(2, len(line)):
                if complex(line[i]) == 0.0:
                    await message.answer('You cant dividing on 0')
                    count = True
                else:
                    if 'j' in line[i]:
                        answer = answer / complex(line[i])
                    else:
                        answer = answer / float(line[i])
                    line2 = line2 + (f" / {line[i]}")
            if count == False:
                await message.answer(f"{line2} = {answer}")

